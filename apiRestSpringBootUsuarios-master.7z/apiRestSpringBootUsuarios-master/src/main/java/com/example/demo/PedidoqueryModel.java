package com.example.demo;

public class PedidoqueryModel {
    public Number idpedido;
    public Number idcliente;
    public Number idempleado;
    public Number idmesa;
    public String fechapedido;
    public Number idestado;

    public PedidoqueryModel(){
    }

}
